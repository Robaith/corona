<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php';?>
</head>
<body>
	<?php include 'navigation.php';?>

</body>
</html>